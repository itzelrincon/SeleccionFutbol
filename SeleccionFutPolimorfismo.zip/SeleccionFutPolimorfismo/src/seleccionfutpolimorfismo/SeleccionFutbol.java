package seleccionfutpolimorfismo;
public abstract class SeleccionFutbol {
    
    protected String nombre, apellido;
    protected int id, edad;
    
    public SeleccionFutbol(String nombre, String apellidos, int id, int edad){
        this.apellido = apellido;
        this.nombre = nombre;
        this.edad = edad;
        this.id = id;
    }
    
    //Getters
    
    public String getNombre(){
        return nombre;
    }
    
    public String getApellido(){
        return apellido;
    }
    
    public int getId(){
        return id;
    }           
    
    public int getEdad(){
        return edad;
    }
    
    //Método gral
    
    public abstract String Accion_Entrenamiento();
    public abstract String Accion_Partido();
 
}