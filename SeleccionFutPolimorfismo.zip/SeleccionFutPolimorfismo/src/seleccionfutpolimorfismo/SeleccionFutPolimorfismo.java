package seleccionfutpolimorfismo;
import java.util.ArrayList;

public class SeleccionFutPolimorfismo {
    
    public static ArrayList<SeleccionFutbol> Seleccion = new ArrayList<>();
    public static ArrayList<SeleccionFutbol> Juego = new ArrayList<>();

}
