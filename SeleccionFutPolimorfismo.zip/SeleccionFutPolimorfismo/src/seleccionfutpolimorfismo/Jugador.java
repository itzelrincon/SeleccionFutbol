package seleccionfutpolimorfismo;

import javax.swing.JTextField;

public class Jugador extends SeleccionFutbol{
    
    protected int dorsal;

    public Jugador(String nombre, String apellidos, int id, int edad,int dorsal) {
        super(nombre, apellidos, id, edad);
        this.dorsal = dorsal;
    }


    @Override
    public String Accion_Entrenamiento() {
        return "Entrena";
    }

    @Override
    public String Accion_Partido() {
        return "Juega";
    }
    
    //Método propio
    
    public void Entrevista(){
        System.out.println("Entrevista a medios");
    }
}