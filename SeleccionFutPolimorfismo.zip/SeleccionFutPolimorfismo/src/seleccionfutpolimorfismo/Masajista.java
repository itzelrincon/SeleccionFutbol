package seleccionfutpolimorfismo;
public class Masajista extends SeleccionFutbol{
    
    private String titulacion;
    private int experiencia;

    public Masajista(String nombre, String apellidos, int id, int edad, String titulacion, int experiencia) {
        super(nombre, apellidos, id, edad);
        this.experiencia = experiencia;
        this.titulacion = titulacion;                                             
    }
    
    //Sobreescritos   
    @Override
    public String Accion_Entrenamiento() {
        return "Masaje de preparamiento";
    }       

    @Override
    public String Accion_Partido() {
        return "Dar masaje";
    }
    
    public void Masaje(){
        System.out.print("Hacer masaje");
    }
}