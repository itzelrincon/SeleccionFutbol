package seleccionfutpolimorfismo;

public class Entrenador extends SeleccionFutbol{
    
    protected int idFed;
    

    public Entrenador(String nombre, String apellidos, int id, int edad, int idFed) {
        super(nombre, apellidos, id, edad);
        this.idFed = idFed;
    }
    
    //Getters    
    public int getIdFed(){
        return idFed;
    }
    
    @Override
    public String Accion_Entrenamiento() {
        return "Dirigir entrenamiento";        
    }

    @Override
    public String Accion_Partido() {
        return "Dirigir partido";
    }
}